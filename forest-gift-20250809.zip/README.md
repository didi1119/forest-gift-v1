# 靜謐森林 - 知音計畫禮物工具包

一個為知音大使設計的個人化森林禮物分享平台。

## 🚀 快速部署

### 方法一：Netlify（推薦）

1. **準備 GitHub 儲存庫**
   ```bash
   # 在本地初始化 Git
   git init
   git add .
   git commit -m "Initial commit"
   
   # 推送到 GitHub
   git remote add origin https://github.com/你的用戶名/forest-gift.git
   git push -u origin main
   ```

2. **連接 Netlify**
   - 前往 [netlify.com](https://netlify.com)
   - 點擊「New site from Git」
   - 連接 GitHub 帳號並選擇儲存庫
   - 部署設定會自動讀取 `netlify.toml`

3. **獲取網址**
   - 部署完成後會得到如：`https://amazing-forest-12345.netlify.app`
   - 可在 Netlify 後台自訂網域名稱

### 方法二：Vercel

1. **安裝 Vercel CLI**
   ```bash
   npm i -g vercel
   ```

2. **部署**
   ```bash
   vercel --prod
   ```

### 方法三：GitHub Pages

1. **推送到 GitHub**
2. **在儲存庫設定中啟用 GitHub Pages**
3. **選擇 main 分支作為來源**

## 🔧 部署後設定

### 1. 更新連結生成器
部署完成後，打開 `link-generator.html`，將「網站根網址」更新為實際網址：
```
https://your-actual-domain.netlify.app
```

### 2. 生成知音大使連結
1. 開啟 `https://your-domain.com/link-generator.html`
2. 填寫大使資訊和 LINE 優惠券連結
3. 生成專屬分享連結

### 3. 設定環境變數
參考 `environment-setup.md` 在 Netlify 後台設定：
- Google Sheets API 金鑰
- Netlify API Token
- GitHub 儲存庫連結

### 4. 測試功能
- 管理後台：`https://your-domain.com/admin-dashboard.html`
- 連結生成器：`https://your-domain.com/link-generator.html`
- 測試個人化：`https://your-domain.com?amb=test&name=測試大使`
- 確認自動化流程正常運作

## 📱 功能說明

### 🎁 訪客體驗
- **🎴 每日占卜**：每人每天限抽一次牌卡
- **🎵 音樂療癒**：私房歌單頁面
- **📖 七日手冊**：內心地圖繪製，自動保存
- **📜 森林故事**：品牌故事頁面
- **🔗 專屬連結**：知音大使個人化分享系統

### 🤖 自動化系統
- **🚀 一鍵部署**：輸入大使資料，自動創建專屬網站
- **📊 即時追蹤**：自動記錄點擊、轉換等績效數據
- **🗄️ 雲端資料庫**：Google Sheets 自動管理大使資料
- **📈 管理後台**：即時查看所有大使績效報表

## 🛠️ 技術架構

- **前端**：HTML + CSS (Tailwind) + JavaScript
- **字體**：Google Fonts (Noto Sans TC / Noto Serif TC)
- **圖片**：Google Drive 直連
- **資料存儲**：localStorage (本地端)
- **部署**：靜態網站托管

## 📞 支援

如有技術問題，請聯繫開發團隊。 