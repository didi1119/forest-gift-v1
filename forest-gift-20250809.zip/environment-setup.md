# 環境變數設定指南

## 🔑 必要的環境變數

在 Netlify 後台的 **Site settings > Environment variables** 中設定以下變數：

### 1. Google Sheets API 設定

```
GOOGLE_SHEET_ID=your_google_sheet_id_here
GOOGLE_CLIENT_EMAIL=your-service-account@project.iam.gserviceaccount.com  
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYour private key here\n-----END PRIVATE KEY-----"
```

**取得方式：**
1. 前往 [Google Cloud Console](https://console.cloud.google.com/)
2. 建立新專案或選擇現有專案
3. 啟用 Google Sheets API
4. 建立服務帳號金鑰
5. 下載 JSON 金鑰檔案

### 2. Netlify API 設定

```
NETLIFY_ACCESS_TOKEN=your_netlify_access_token_here
```

**取得方式：**
1. 前往 Netlify 後台
2. User settings > Applications > Personal access tokens
3. Generate new token

### 3. GitHub 儲存庫設定

```
GITHUB_REPO_URL=https://github.com/your-username/forest-gift.git
```

## 📊 Google Sheets 資料庫結構

### 主要工作表（第一個工作表）
| 欄位名稱 | 說明 |
|---------|------|
| ambassadorId | 大使代碼 |
| ambassadorName | 大使姓名 |
| lineLink | 專屬 LINE 優惠券連結 |
| contactInfo | 聯絡資訊 |
| siteUrl | 專屬網站網址 |
| netlifyId | Netlify 站點 ID |
| createdAt | 建立時間 |
| status | 狀態（active/inactive） |
| totalClicks | 總點擊數 |
| totalConversions | 總轉換數 |
| lastActiveAt | 最後活動時間 |

### 活動記錄工作表
| 欄位名稱 | 說明 |
|---------|------|
| ambassadorId | 大使代碼 |
| eventType | 事件類型 |
| timestamp | 時間戳記 |
| userAgent | 用戶代理 |
| referer | 來源頁面 |
| ip | IP 地址 |
| additionalData | 額外資料 |

## 🚀 部署步驟

1. **設定環境變數**：在 Netlify 後台設定上述變數
2. **建立 Google Sheets**：使用上述結構建立工作表
3. **部署網站**：推送程式碼到 GitHub 並連接 Netlify
4. **測試功能**：使用連結生成器測試自動化流程

## ⚠️ 注意事項

- Google Sheets ID 可從試算表網址取得：`https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit`
- 私鑰需要保持完整格式，包含 `\n` 換行符號
- 確保服務帳號有權限存取目標試算表 